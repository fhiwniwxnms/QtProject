# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.8.0
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01~\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
-960 960 960\x22 wi\
dth=\x2224px\x22 fill=\
\x22#5f6368\x22><path \
d=\x22M280-280h160v\
-160H280v160Zm24\
0 0h160v-160H520\
v160ZM280-520h16\
0v-160H280v160Zm\
240 0h160v-160H5\
20v160ZM200-120q\
-33 0-56.5-23.5T\
120-200v-560q0-3\
3 23.5-56.5T200-\
840h560q33 0 56.\
5 23.5T840-760v5\
60q0 33-23.5 56.\
5T760-120H200Zm0\
-80h560v-560H200\
v560Zm0-560v560-\
560Z\x22/></svg>\
\x00\x00\x00\xb6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
-960 960 960\x22 wi\
dth=\x2224px\x22 fill=\
\x22#434343\x22><path \
d=\x22M440-440H200v\
-80h240v-240h80v\
240h240v80H520v2\
40h-80v-240Z\x22/><\
/svg>\
\x00\x00\x03\xa3\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
-960 960 960\x22 wi\
dth=\x2224px\x22 fill=\
\x22#5f6368\x22><path \
d=\x22M200-80q-33 0\
-56.5-23.5T120-1\
60v-560q0-33 23.\
5-56.5T200-800h4\
0v-80h80v80h320v\
-80h80v80h40q33 \
0 56.5 23.5T840-\
720v560q0 33-23.\
5 56.5T760-80H20\
0Zm0-80h560v-400\
H200v400Zm0-480h\
560v-80H200v80Zm\
0 0v-80 80Zm280 \
240q-17 0-28.5-1\
1.5T440-440q0-17\
 11.5-28.5T480-4\
80q17 0 28.5 11.\
5T520-440q0 17-1\
1.5 28.5T480-400\
Zm-160 0q-17 0-2\
8.5-11.5T280-440\
q0-17 11.5-28.5T\
320-480q17 0 28.\
5 11.5T360-440q0\
 17-11.5 28.5T32\
0-400Zm320 0q-17\
 0-28.5-11.5T600\
-440q0-17 11.5-2\
8.5T640-480q17 0\
 28.5 11.5T680-4\
40q0 17-11.5 28.\
5T640-400ZM480-2\
40q-17 0-28.5-11\
.5T440-280q0-17 \
11.5-28.5T480-32\
0q17 0 28.5 11.5\
T520-280q0 17-11\
.5 28.5T480-240Z\
m-160 0q-17 0-28\
.5-11.5T280-280q\
0-17 11.5-28.5T3\
20-320q17 0 28.5\
 11.5T360-280q0 \
17-11.5 28.5T320\
-240Zm320 0q-17 \
0-28.5-11.5T600-\
280q0-17 11.5-28\
.5T640-320q17 0 \
28.5 11.5T680-28\
0q0 17-11.5 28.5\
T640-240Z\x22/></sv\
g>\
\x00\x00\x02?\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
-960 960 960\x22 wi\
dth=\x2224px\x22 fill=\
\x22#5f6368\x22><path \
d=\x22M320-160q-33 \
0-56.5-23.5T240-\
240v-120h120v-90\
q-35-2-66.5-15.5\
T236-506v-44h-46\
L60-680q36-46 89\
-65t107-19q27 0 \
52.5 4t51.5 15v-\
55h480v520q0 50-\
35 85t-85 35H320\
Zm120-200h240v80\
q0 17 11.5 28.5T\
720-240q17 0 28.\
5-11.5T760-280v-\
440H440v24l240 2\
40v56h-56L510-51\
4l-8 8q-14 14-29\
.5 25T440-464v10\
4ZM224-630h92v86\
q12 8 25 11t27 3\
q23 0 41.5-7t36.\
5-25l8-8-56-56q-\
29-29-65-43.5T25\
6-684q-20 0-38 3\
t-36 9l42 42Zm37\
6 350H320v40h286\
q-3-9-4.5-19t-1.\
5-21Zm-280 40v-4\
0 40Z\x22/></svg>\
\x00\x00\x01&\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
-960 960 960\x22 wi\
dth=\x2224px\x22 fill=\
\x22#434343\x22><path \
d=\x22M280-120v-120\
h-80v-80h80v-80h\
-80v-80h80v-360h\
260q92 0 156 64t\
64 156q0 92-64 1\
56t-156 64H360v8\
0h160v80H360v120\
h-80Zm80-360h180\
q58 0 99-41t41-9\
9q0-58-41-99t-99\
-41H360v280Z\x22/><\
/svg>\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x11\
\x0d\xc5\x1e\xa7\
\x00C\
\x00a\x00t\x00e\x00g\x00o\x00r\x00y\x00 \x00n\x00a\x00m\x00e\x00.\x00s\x00v\x00g\
\
\x00\x07\
\x07\xa7ZG\
\x00A\
\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x0c\
\x03\xb5\x02G\
\x00C\
\x00a\x00l\x00e\x00n\x00d\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x0f\
\x0f2~\xa7\
\x00D\
\x00e\x00s\x00c\x00r\x00i\x00p\x00t\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09/m\xc7\
\x00R\
\x00u\x00b\x00b\x00l\x00e\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x05\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\x02<\
\x00\x00\x01\x93\x10\xdf\xc80\
\x00\x00\x008\x00\x00\x00\x00\x00\x01\x00\x00\x01\x82\
\x00\x00\x01\x93\x07Q`\xd0\
\x00\x00\x00\x8e\x00\x00\x00\x00\x00\x01\x00\x00\x08&\
\x00\x00\x01\x93\x07R\xb8\x90\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x93\x10\xe4\xf4\xbe\
\x00\x00\x00j\x00\x00\x00\x00\x00\x01\x00\x00\x05\xe3\
\x00\x00\x01\x93\x10\xe3\xa2\x97\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
